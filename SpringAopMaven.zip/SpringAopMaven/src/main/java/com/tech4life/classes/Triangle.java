package com.tech4life.classes;

public class Triangle {
	private String name;

	public Triangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Triangle(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
