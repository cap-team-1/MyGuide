package com.tech4life.classes;

public class Circle {
private String name;

public Circle() {
	super();
	// TODO Auto-generated constructor stub
}

public Circle(String name) {
	super();
	this.name = name;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

}
