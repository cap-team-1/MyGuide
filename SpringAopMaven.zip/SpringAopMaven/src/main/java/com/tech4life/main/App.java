package com.tech4life.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tech4life.classes.ShapeService;
public class App 
{
   

	public static void main( String[] args )
    {
		 ApplicationContext ctx = new ClassPathXmlApplicationContext("index.xml");
    	ShapeService service=ctx.getBean("shapeServices",ShapeService.class);
    	System.out.println(service.getTriangle().getName());
    }
}
