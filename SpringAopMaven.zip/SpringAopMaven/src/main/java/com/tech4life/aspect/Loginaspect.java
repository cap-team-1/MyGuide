package com.tech4life.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
@Aspect
public class Loginaspect {
@Before("execution(public * get*())")
public void loadingAdvice() {
	System.out.println("run before get circle");
}

}
